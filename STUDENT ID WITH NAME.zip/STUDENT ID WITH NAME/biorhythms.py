import matplotlib.dates as mdates
from pylab import *
# from numpy import array,sin,pi
from numpy import *
from datetime import date

birth_day = input('Enter BirthDate in Format dd-mm-yyyy : ')
target_day = input('Enter TargetDate In  Format dd-mm-yyyy : ')


birth_day = birth_day.strip()
target_day = target_day.strip()


def Day_Month_Year(birth_day,target_day):
    try:

        day,month,year = birth_day.split('-')
        day,month,year = target_day.split('-')
        birthday = date(int(year),int(month),int(day)).toordinal()
        targetdate = date(int(year),int(month),int(day)).toordinal()
        return birthday,targetdate
    except Exception as er1:
        print('Error in date Format', str(er1))


def Range_In_Days(targetdate):

    try:

        Range_Days = array(range((targetdate-3),(targetdate+31)))
        return Range_Days
    except Exception as er2:
        print('Error in Range days', str(er2))


def CallBiorhythms(Range_Days, birthday):
    try:

        physical = sin(2*pi*(Range_Days-birthday)/23)
        emotional = sin(2*pi*(Range_Days-birthday)/28)
        intellectual = sin(2*pi*(Range_Days-birthday)/33)

        list_cycles = [physical,emotional,intellectual]

        return list_cycles
    except Exception as er3:
        print('Error in Biorhythms Formulas', str(er3))



def Show_Graph(Range_Days,list_cycles):

    try:

        label = []
        for px in Range_Days:
         label.append(date.fromordinal(px))

        fig = figure()
        f_ax = fig.gca()
        plot(label,list_cycles[0], linewidth=3, color="r", alpha=.5)
        plot(label,list_cycles[1], linewidth=3, color="b", alpha=.5)
        plot(label,list_cycles[2], linewidth=3, color="g", alpha=.5)

        # adding a legend
        legend(['Physical', 'Emotional', 'Intellectual'],loc='upper right')
        title("Biorhythms Graph")
        # formatting the dates on the x axis
        f_ax.xaxis.set_major_formatter(mdates.DateFormatter('%d\n%b\n%y\n%a'))
        show()
    except Exception as er4:
        print('Error in Graph plot', str(er4))

if "-" in birth_day and "-" in target_day:

    birthday,targetdate = Day_Month_Year(birth_day,target_day)
    Range_Days = Range_In_Days(targetdate)
    list_cycles = CallBiorhythms(Range_Days, birthday)

    Show_Graph(Range_Days,list_cycles)
else:
    print('Date format are incorrect')






