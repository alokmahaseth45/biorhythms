from datetime import date
import matplotlib.dates as mdates
from pylab import *
from numpy import array,sin,pi

# birth_date = input('Enter Birth Date in Format dd/mm/yyyy : ')
# target_date = input('Enter Target Date In  Format dd/mm/yyyy : ')

birth_date = '04/10/1990'
target_date = '30/05/2019'


dd,mm,yy = birth_date.split('/')
dd1,mm1,yy1 = target_date.split('/')
bday = date(int(yy),int(mm),int(dd)).toordinal()
targetdate = date(int(yy1),int(mm1),int(dd1)).toordinal()
day_range = array(range((targetdate-3),(targetdate+31)))


Physical = sin(2*pi*(day_range-bday)/23)
Emotional = sin(2*pi*(day_range-bday)/28)
Intellectual = sin(2*pi*(day_range-bday)/33)

y = [Physical,Emotional,Intellectual]
print(y)



# converting ordinals to date
label = []
for p in day_range:
 label.append(date.fromordinal(p))

fig = figure()
ax = fig.gca()
plot(label,y[0], linewidth=2, color="r", alpha=.7)
plot(label,y[1], linewidth=2, color="b", alpha=.7)
plot(label,y[2], linewidth=2, color="g", alpha=.7)

# adding a legend
legend(['Physical', 'Emotional', 'Intellectual'],loc='upper right')
title("Biorhythms")
# formatting the dates on the x axis
ax.xaxis.set_major_formatter(mdates.DateFormatter('%d\n%b\n%y\n%a'))

show()