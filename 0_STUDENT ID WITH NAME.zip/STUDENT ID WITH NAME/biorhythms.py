from datetime import date
import datetime
# from datetime import date,strptime,toordinal
import matplotlib.dates as dt
import matplotlib.pyplot as plt
from numpy import array,sin,pi


def convert_date_to_ordinal(str_date):
    date_arr = str_date.split('-')
    year,month,day = date_arr[0], date_arr[1], date_arr[2]
    d = datetime.datetime(int(year),int(month),int(day))
    return d.toordinal()

def get_input():
	print("Please Enter Your Birth Date in the Format YYYY-MM-DD")
	birth_date =raw_input()
	print("Please Enter Target Date in the Format YYYY-MM-DD")
	target_date =raw_input()
	return birth_date,target_date

#Method to get Day in int form using Formaula (year + year/4 - year/100 + year/400) to get number of leap days
def get_day_of_week(date, month, year): 
    day_arr = [ 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 ] 
    if month<=2:
        year -= month
    return (( year + int(year / 4) - int(year / 100) + int(year / 400) + day_arr[month - 1] + date) % 7) 

def f(x):
	return 50.*(x+1)

def sig(q):
	if q>=0: return 1
	return 0

def plot_graph(birth_date,target_date):
	#Ordinals convert datetime object into days and its easy to convert back days into datetime using datetime library
    birth_date_ordinal = convert_date_to_ordinal(birth_date)
    target_date_ordinal = convert_date_to_ordinal(target_date)
    target_range = array(range(target_date_ordinal-15,target_date_ordinal+15)) # range of 31 days

    result =     (sin(2*pi*(target_range-birth_date_ordinal)/23),  # Physical
                  sin(2*pi*(target_range-birth_date_ordinal)/28),  # Emotional
	              sin(2*pi*(target_range-birth_date_ordinal)/33))  # Intellectual

    average = (result[0]+result[1]+result[2])/3

    graph_labels = []
    for label in target_range:
		graph_labels.append(date.fromordinal(label))

    graph_figure = plt.figure(figsize=(14,7))
    axis = graph_figure.gca()
    plt.plot(graph_labels,result[0], color="b", linewidth=4, alpha=.7)
    plt.plot(graph_labels,result[1], color="r", linewidth=4, alpha=.7)
    plt.plot(graph_labels,result[2], color="g", linewidth=4, alpha=.7)
    plt.plot(graph_labels,average, linewidth=2, linestyle="--", color="black")
        
    plt.legend(['Physical', 'Emotional', 'Intellectual','AVERAGE'])

#     plt.ax.xaxis.set_major_formatter(dt.DateFormatter('%d/%b'))
    plt.axhline(0, color="black", linewidth=1.4)
    plt.grid(True, linestyle="-", alpha=.4)
    plt.xlim((target_range[0],target_range[-1]))

    #Title as Birth Date and Target Date
    birth_year,birth_month,birth_day = birth_date.year,birth_date.month, birth_date.day
    target_year,target_month,target_day = target_date.year,target_date.month,target_date.day
    plt.title("%02u.%02u.%04u ---  %02u.%02u.%04u" % (birth_year,birth_month,birth_day,target_year,
                                                    target_month,target_day))

    fig_name = "{}-{}-{}.pdf".format(birth_year,birth_month,birth_day)
    plt.savefig(fig_name)
    plt.show()

    return "Plotted Figure"

if __name__ == '__main__':
    birth_date,target_date = get_input()
    plot_graph(birth_date,target_date)